class MenuState {
  var camQuery=false;
  var waitingQr='';
  var waitingFood='';
  dynamic waitingId=0;
  MenuState() {
    ///Initialize variables
  }

}
